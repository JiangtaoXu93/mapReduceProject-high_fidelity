package Algorithm

import data.SongInfo
import org.apache.spark.rdd.RDD

object Graphs {

  def runGraphs(songInfos: RDD[SongInfo]): Unit = {


  }


}
